from .Wappalyzer import WebPage, Wappalyzer

Wappalyzer = Wappalyzer
WebPage = WebPage
